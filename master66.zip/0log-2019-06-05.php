<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-06-05 09:13:18 --> Severity: Warning --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\xampp\htdocs\master\system\libraries\Email.php 1888
ERROR - 2019-06-05 09:13:22 --> Página no encontrada: Assets/images
ERROR - 2019-06-05 09:13:49 --> Página no encontrada: Assets/images
